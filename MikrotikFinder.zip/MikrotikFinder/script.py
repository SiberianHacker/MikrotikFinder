import random
import requests
from threading import Thread
import socket
from colorama import init, Fore

init()

def writer(str, path):
    f = open(path, mode="a+", encoding="utf-8")
    print(Fore.GREEN + str)
    f.write(str + "\n")
    f.close()

def findTitle(url):
    try:
        webpage = requests.get(url, timeout=3).content
        title = str(webpage, "utf-8").split('<title>')[1].split('</title>')[0]
    except:
        pass
    else:
        if "RouterOS" in title:
            print(Fore.CYAN + "Найден микроротик! " + url + " " + title)
            writer(url, "mikrotik.txt")
        return title

def check_router():
    while True:
        try:
            ip = str(random.randint(1, 255)) + "." + str(random.randint(1, 255)) + "." + str(random.randint(1, 255)) + "." + str(random.randint(1, 255))
            valid = str(ip) + " " + str(findTitle("http://" + ip + "/"))
        except Exception as e:
            pass
        else:
            if "None" not in valid:
                writer(valid, "url.txt")


for i in range(1000):
    th = Thread(target=check_router)
    th.start()